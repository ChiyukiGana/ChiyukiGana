#if UNITY_EDITOR
#if VRC_SDK_VRCSDK3
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using static VRC.SDKBase.VRC_AvatarParameterDriver;
public class ParameterSaveSetup : EditorWindow
{
    private int slotCount = 4;
    private VRCExpressionParameters sourceParameters;
    private VRCExpressionParameters targetParameters;
    private VRCExpressionsMenu targetMenu;
    private AnimatorController targetAnimatorController;
    private bool clearTargetParameters = false;
    private bool clearTargetAnimator = false;
    [MenuItem("Tools/VRChat Parameter Save Setup")]
    public static void ShowWindow()
    {
        GetWindow<ParameterSaveSetup>("Parameter Save Setup");
    }
    private void OnGUI()
    {
        GUILayout.Label("Parameter Save Setup", EditorStyles.boldLabel);
        EditorGUILayout.Space();
        slotCount = EditorGUILayout.IntSlider("可保存的数量", slotCount, 1, 8);
        sourceParameters = (VRCExpressionParameters)EditorGUILayout.ObjectField("需要的参数", sourceParameters, typeof(VRCExpressionParameters), false);
        targetParameters = (VRCExpressionParameters)EditorGUILayout.ObjectField("保存的参数（空/自己）", targetParameters, typeof(VRCExpressionParameters), false);
        targetMenu = (VRCExpressionsMenu)EditorGUILayout.ObjectField("保存的菜单（空）", targetMenu, typeof(VRCExpressionsMenu), false);
        targetAnimatorController = (AnimatorController)EditorGUILayout.ObjectField("动画控制器（空）", targetAnimatorController, typeof(AnimatorController), false);
        EditorGUILayout.Space();
        clearTargetParameters = EditorGUILayout.Toggle("清空保存的参数", clearTargetParameters);
        clearTargetAnimator = EditorGUILayout.Toggle("清空动画控制器", clearTargetAnimator);
        EditorGUILayout.Space();
        EditorGUILayout.HelpBox("\n1. 将需要的参数单独保存在一个菜单参数里面然后放入【需要的参数】\n\n2. 选择用于保存生成参数的菜单参数并放入【保存的参数（空/自己）】\n\n3. 选择一个空菜单保存生成的菜单\n\n4. 选择用于处理保存系统的动画控制器，建议选择空的并用MA合并到FX层\n\n完成生成后可以用MA Merge Animator，MA Parameters，MA Menu Install来安装\n", MessageType.Info);
        EditorGUILayout.Space();
        GUI.enabled = IsSetupValid();
        if (GUILayout.Button("生成参数保存系统", GUILayout.Height(30))) GenerateSaveSystem();
        GUI.enabled = true;
        if (!IsSetupValid()) EditorGUILayout.HelpBox("请确保添加了全部引用", MessageType.Warning);
    }
    private bool IsSetupValid()
    {
        return sourceParameters != null && targetParameters != null && targetMenu != null && targetAnimatorController != null;
    }
    private void GenerateSaveSystem()
    {
        if (!EditorUtility.DisplayDialog("参数保存系统", "执行操作会修改或清空目标参数，菜单，控制器，确保没有清空主参数！", "确认", "取消")) return;
        Undo.RecordObjects(new Object[] { targetParameters, targetMenu, targetAnimatorController }, "Generate Parameter Save System");
        try
        {
            AssetDatabase.StartAssetEditing();
            MenuParametersSetup();
            MenuSetup();
            AnimatorSetup();
            SaveAssets();
            EditorUtility.DisplayDialog("成功", "已生成参数保存系统", "OK");
        }
        catch (System.Exception e)
        {
            EditorUtility.DisplayDialog("失败", $"未生成参数保存系统: {e.Message}", "OK");
            Debug.LogError(e);
        }
        finally
        {
            AssetDatabase.StopAssetEditing();
        }
    }
    private void MenuParametersSetup()
    {
        sourceParameterSaved = sourceParameters.parameters;
        if (clearTargetParameters) targetParameters.parameters = new VRCExpressionParameters.Parameter[0];
        var existingParams = targetParameters.parameters?.ToList() ?? new List<VRCExpressionParameters.Parameter>();
        MenuParametersAdd(existingParams, "SavedSet_Index", VRCExpressionParameters.ValueType.Int, saved: false, synced: false, defaultValue: 0);
        MenuParametersAdd(existingParams, "SavedSet_Load", VRCExpressionParameters.ValueType.Bool, saved: false, synced: false, defaultValue: 0);
        MenuParametersAdd(existingParams, "SavedSet_Save", VRCExpressionParameters.ValueType.Bool, saved: false, synced: false, defaultValue: 0);
        for (int i = 0; i < slotCount; i++)
        {
            int slotNumber = i + 1;

            foreach (var sourceParam in sourceParameterSaved)
            {
                string savedParamName = $"SavedSet_{slotNumber}/{sourceParam.name}";
                MenuParametersAdd(existingParams, savedParamName, sourceParam.valueType, saved: true, synced: false, sourceParam.defaultValue);
            }
        }
        targetParameters.parameters = existingParams.ToArray();
        EditorUtility.SetDirty(targetParameters);
    }
    private void MenuParametersAdd(List<VRCExpressionParameters.Parameter> parameters, string name, VRCExpressionParameters.ValueType type, bool saved, bool synced, float defaultValue)
    {
        if (!parameters.Any(p => p.name == name))
        {
            parameters.Add(new VRCExpressionParameters.Parameter
            {
                name = name,
                valueType = type,
                saved = saved,
                defaultValue = defaultValue,
                networkSynced = synced
            });
        }
    }
    private void MenuSetup()
    {
        if (targetMenu.controls == null) targetMenu.controls = new List<VRCExpressionsMenu.Control>();
        targetMenu.controls.Clear();
        for (int i = 0; i < slotCount && i < 8; i++)
        {
            int slotNumber = i + 1;
            targetMenu.controls.Add(MenuCreateSaveSubMenu(slotNumber));
            targetMenu.controls[i].parameter = new VRCExpressionsMenu.Control.Parameter { name = "SavedSet_Index" };
            targetMenu.controls[i].value = slotNumber;
        }
        EditorUtility.SetDirty(targetMenu);
    }
    private VRCExpressionsMenu.Control MenuCreateSaveSubMenu(int slotNumber)
    {
        var subMenu = CreateInstance<VRCExpressionsMenu>();
        subMenu.name = $"{targetMenu.name}_Set{slotNumber}";
        subMenu.Parameters = targetParameters;
        subMenu.controls = new List<VRCExpressionsMenu.Control>
        {
            new VRCExpressionsMenu.Control
            {
                name = "Load",
                type = VRCExpressionsMenu.Control.ControlType.Button,
                parameter = new VRCExpressionsMenu.Control.Parameter { name = "SavedSet_Load" },
                value = 1
            },
            new VRCExpressionsMenu.Control
            {
                name = "Save",
                type = VRCExpressionsMenu.Control.ControlType.Button,
                parameter = new VRCExpressionsMenu.Control.Parameter { name = "SavedSet_Save" },
                value = 1
            }
        };
        string menuPath = AssetDatabase.GetAssetPath(targetMenu);
        string directory = System.IO.Path.GetDirectoryName(menuPath);
        string subMenuPath = $"{directory}/{subMenu.name}.asset";
        AssetDatabase.CreateAsset(subMenu, subMenuPath);
        return new VRCExpressionsMenu.Control
        {
            name = $"Set{slotNumber}",
            type = VRCExpressionsMenu.Control.ControlType.SubMenu,
            subMenu = subMenu
        };
    }
    private void AnimatorParameterAdd(string name, AnimatorControllerParameterType type)
    {
        if (!targetAnimatorController.parameters.Any(p => p.name == name)) targetAnimatorController.AddParameter(name, type);
    }
    private void AnimatorSetup()
    {
        if (clearTargetAnimator)
        {
            targetAnimatorController.layers = new AnimatorControllerLayer[0];
            targetAnimatorController.parameters = new AnimatorControllerParameter[0];
        }
        foreach (var sourceParam in sourceParameterSaved) AnimatorParameterAdd(sourceParam.name, ToAnimatorControllerType(sourceParam.valueType));
        AnimatorParameterAdd("SavedSet_Index", AnimatorControllerParameterType.Int);
        AnimatorParameterAdd("SavedSet_Load", AnimatorControllerParameterType.Bool);
        AnimatorParameterAdd("SavedSet_Save", AnimatorControllerParameterType.Bool);
        for (int i = 0; i < slotCount; i++)
        {
            int slotNumber = i + 1;

            foreach (var sourceParam in sourceParameterSaved)
            {
                string savedParamName = $"SavedSet_{slotNumber}/{sourceParam.name}";
                AnimatorParameterAdd(savedParamName, ToAnimatorControllerType(sourceParam.valueType));
            }
        }
        AnimatorCreateSaveLayer();
        EditorUtility.SetDirty(targetAnimatorController);
    }
    private void AnimatorCreateSaveLayer()
    {
        string layerName = "SaveSystem";
        var existingLayer = targetAnimatorController.layers.FirstOrDefault(l => l.name == layerName);
        if (existingLayer != null)
        {
            var layerList = targetAnimatorController.layers.ToList();
            layerList.Remove(existingLayer);
            targetAnimatorController.layers = layerList.ToArray();
        }
        var layer = new AnimatorControllerLayer
        {
            name = layerName,
            stateMachine = new AnimatorStateMachine
            {
                name = layerName,
                hideFlags = HideFlags.HideInHierarchy
            },
            defaultWeight = 1f
        };
        if (AssetDatabase.GetAssetPath(targetAnimatorController) != "") AssetDatabase.AddObjectToAsset(layer.stateMachine, targetAnimatorController);
        AnimatorStateMachine stateMachine = layer.stateMachine;
        var idleState = stateMachine.AddState("Idle");
        stateMachine.defaultState = idleState;
        for (int i = 0; i < slotCount; i++)
        {
            int slotNumber = i + 1;
            AnimatorCreateLoadState(stateMachine, idleState, slotNumber);
            AnimatorCreateSaveState(stateMachine, idleState, slotNumber);
        }
        var layersList = targetAnimatorController.layers.ToList();
        layersList.Add(layer);
        targetAnimatorController.layers = layersList.ToArray();
    }
    private void AnimatorCreateLoadState(AnimatorStateMachine stateMachine, AnimatorState idleState, int slotNumber)
    {
        string stateName = $"LoadSet{slotNumber}";
        var loadState = stateMachine.AddState(stateName);
        var driver = loadState.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
        driver.parameters = new List<Parameter>();
        foreach (var sourceParam in sourceParameterSaved)
        {
            driver.parameters.Add(new Parameter
            {
                name = sourceParam.name,
                type = ChangeType.Copy,
                source = $"SavedSet_{slotNumber}/{sourceParam.name}"
            });
        }
        var transition = idleState.AddTransition(loadState);
        transition.AddCondition(AnimatorConditionMode.Equals, slotNumber, "SavedSet_Index");
        transition.AddCondition(AnimatorConditionMode.If, 1, "SavedSet_Load");
        transition.hasExitTime = false;
        transition.duration = 0;
        var returnTransition = loadState.AddTransition(idleState);
        returnTransition.hasExitTime = true;
        returnTransition.exitTime = 0.1f;
        returnTransition.duration = 0.1f;
    }
    private void AnimatorCreateSaveState(AnimatorStateMachine stateMachine, AnimatorState idleState, int slotNumber)
    {
        string stateName = $"SaveSet{slotNumber}";
        var saveState = stateMachine.AddState(stateName);
        var driver = saveState.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
        driver.parameters = new List<Parameter>();
        foreach (var sourceParam in sourceParameterSaved)
        {
            driver.parameters.Add(new Parameter
            {
                name = $"SavedSet_{slotNumber}/{sourceParam.name}",
                type = ChangeType.Copy,
                source = sourceParam.name
            });
        }
        var transition = idleState.AddTransition(saveState);
        transition.AddCondition(AnimatorConditionMode.Equals, slotNumber, "SavedSet_Index");
        transition.AddCondition(AnimatorConditionMode.If, 1, "SavedSet_Save");
        transition.hasExitTime = false;
        transition.duration = 0;
        var returnTransition = saveState.AddTransition(idleState);
        returnTransition.hasExitTime = true;
        returnTransition.exitTime = 0.1f;
        returnTransition.duration = 0.1f;
    }
    private void SaveAssets()
    {
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }
    private AnimatorControllerParameterType ToAnimatorControllerType(VRCExpressionParameters.ValueType type)
    {
        return type switch
        {
            VRCExpressionParameters.ValueType.Bool => AnimatorControllerParameterType.Bool,
            VRCExpressionParameters.ValueType.Int => AnimatorControllerParameterType.Int,
            VRCExpressionParameters.ValueType.Float => AnimatorControllerParameterType.Float,
            _ => AnimatorControllerParameterType.Float
        };
    }
    private VRCExpressionParameters.Parameter[] sourceParameterSaved;
}
#endif
#endif