#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using System;
public class ObjectCapture : EditorWindow
{
    private int width = 1920;
    private int height = 1080;
    private Camera renderCamera;
    private List<GameObject> selectedObjects = new List<GameObject>();
    private string savePath = "Assets/ObjectCapture/";
    private const int TEMP_LAYER = 31;
    private Texture2D previewTexture;
    private RenderTexture previewRenderTexture;
    private Camera previewCamera;
    private Vector2 previewScrollPosition;
    private bool showPreview = false;
    [MenuItem("Tools/Object Capture")]
    public static void ShowWindow()
    {
        GetWindow<ObjectCapture>("Object Capture");
    }
    void OnGUI()
    {
        GUILayout.Label("Object Capture Settings", EditorStyles.boldLabel);
        EditorGUILayout.BeginHorizontal();
        width = EditorGUILayout.IntField("Width", width);
        height = EditorGUILayout.IntField("Height", height);
        EditorGUILayout.EndHorizontal();
        renderCamera = EditorGUILayout.ObjectField("相机", renderCamera, typeof(Camera), true) as Camera;
        EditorGUILayout.Space();
        GUILayout.Label("拍摄的对象");
        for (int i = 0; i < selectedObjects.Count; i++)
        {
            EditorGUILayout.BeginHorizontal();
            selectedObjects[i] = EditorGUILayout.ObjectField(selectedObjects[i], typeof(GameObject), true) as GameObject;
            if (GUILayout.Button("移除", GUILayout.Width(60)))
            {
                selectedObjects.RemoveAt(i);
                i--;
            }
            EditorGUILayout.EndHorizontal();
        }
        if (GUILayout.Button("添加选中对象"))
        {
            foreach (GameObject obj in Selection.gameObjects) if (!selectedObjects.Contains(obj)) selectedObjects.Add(obj);
        }
        EditorGUILayout.Space();
        EditorGUILayout.BeginHorizontal();
        savePath = EditorGUILayout.TextField("保存位置", savePath);
        if (GUILayout.Button("选择", GUILayout.Width(80)))
        {
            string path = EditorUtility.SaveFolderPanel("Select Save Folder", savePath, "");
            if (!string.IsNullOrEmpty(path)) savePath = path + "/";
        }
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.Space();
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("预览", GUILayout.Height(30))) PreviewScreenshot();
        if (GUILayout.Button("创建截图", GUILayout.Height(30))) TakeScreenshot();
        EditorGUILayout.EndHorizontal();
        if (showPreview && previewTexture != null)
        {
            EditorGUILayout.Space();
            GUILayout.Label("预览图像", EditorStyles.boldLabel);
            previewScrollPosition = EditorGUILayout.BeginScrollView(previewScrollPosition, GUILayout.MaxHeight(600));
            float aspectRatio = (float)previewTexture.width / previewTexture.height;
            float displayWidth = Mathf.Min(position.width - 50, previewTexture.width);
            float displayHeight = displayWidth / aspectRatio;
            Rect rect = GUILayoutUtility.GetRect(displayWidth, displayHeight);
            EditorGUI.DrawPreviewTexture(rect, previewTexture);
            EditorGUILayout.EndScrollView();
            GUILayout.Label($"Preview Size: {previewTexture.width} x {previewTexture.height}");
            if (GUILayout.Button("清除预览", GUILayout.Height(30))) ClearPreview();
        }
    }

    void PreviewScreenshot()
    {
        if (selectedObjects.Count == 0)
        {
            EditorUtility.DisplayDialog("Error", "Please select at least one GameObject", "OK");
            return;
        }
        ClearPreview();
        previewCamera = CreateTempCamera();
        previewRenderTexture = new RenderTexture(width, height, 24);
        previewCamera.targetTexture = previewRenderTexture;
        Dictionary<GameObject, int> originalLayers = new Dictionary<GameObject, int>();
        foreach (GameObject obj in selectedObjects) SetLayerRecursive(obj, TEMP_LAYER, originalLayers);
        previewCamera.cullingMask = 1 << TEMP_LAYER;
        RenderTexture.active = previewRenderTexture;
        previewCamera.Render();
        previewTexture = new Texture2D(width, height, TextureFormat.ARGB32, false);
        previewTexture.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        previewTexture.Apply();
        foreach (var pair in originalLayers) pair.Key.layer = pair.Value;
        RenderTexture.active = null;
        showPreview = true;
    }

    void ClearPreview()
    {
        showPreview = false;
        if (previewTexture != null)
        {
            DestroyImmediate(previewTexture);
            previewTexture = null;
        }
        if (previewRenderTexture != null)
        {
            DestroyImmediate(previewRenderTexture);
            previewRenderTexture = null;
        }
        if (previewCamera != null)
        {
            DestroyImmediate(previewCamera.gameObject);
            previewCamera = null;
        }
    }

    void TakeScreenshot()
    {
        if (selectedObjects.Count == 0)
        {
            EditorUtility.DisplayDialog("Error", "Please select at least one GameObject", "OK");
            return;
        }
        if (!Directory.Exists(savePath)) Directory.CreateDirectory(savePath);
        ClearPreview();
        Camera tempCamera = CreateTempCamera();
        RenderTexture rt = new RenderTexture(width, height, 24);
        tempCamera.targetTexture = rt;
        Dictionary<GameObject, int> originalLayers = new Dictionary<GameObject, int>();
        foreach (GameObject obj in selectedObjects) SetLayerRecursive(obj, TEMP_LAYER, originalLayers);
        tempCamera.cullingMask = 1 << TEMP_LAYER;
        RenderTexture.active = rt;
        tempCamera.Render();
        Texture2D texture = new Texture2D(width, height, TextureFormat.ARGB32, false);
        texture.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        texture.Apply();
        foreach (var pair in originalLayers) pair.Key.layer = pair.Value;
        byte[] bytes = texture.EncodeToPNG();
        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string filePath = Path.Combine(savePath, $"screenshot_{timestamp}.png");
        File.WriteAllBytes(filePath, bytes);
        RenderTexture.active = null;
        DestroyImmediate(tempCamera.gameObject);
        DestroyImmediate(rt);
        DestroyImmediate(texture);
        AssetDatabase.Refresh();
        Debug.Log($"Screenshot saved to: {filePath}");
    }
    Camera CreateTempCamera()
    {
        GameObject tempCamObj = new GameObject("TempScreenshotCamera");
        Camera tempCamera = tempCamObj.AddComponent<Camera>();
        if (renderCamera != null) tempCamera.CopyFrom(renderCamera);
        else
        {
            tempCamera.transform.position = new Vector3(0, 1, -10);
            tempCamera.transform.LookAt(Vector3.zero);
            tempCamera.orthographic = false;
            tempCamera.fieldOfView = 60;
        }
        tempCamera.clearFlags = CameraClearFlags.SolidColor;
        tempCamera.backgroundColor = new Color(0, 0, 0, 0);
        return tempCamera;
    }

    void SetLayerRecursive(GameObject obj, int layer, Dictionary<GameObject, int> originalLayers)
    {
        if (obj == null) return;
        originalLayers[obj] = obj.layer;
        obj.layer = layer;
        foreach (Transform child in obj.transform) SetLayerRecursive(child.gameObject, layer, originalLayers);
    }
    private void OnDestroy()
    {
        ClearPreview();
    }
}
#endif